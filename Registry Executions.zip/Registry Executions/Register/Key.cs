﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;

namespace CachedProgramsList.Register
{
    class Key
    {
        private string key;

        public Key(string key)
        {
            this.key = key;
        }

        public List<Entry> getEntries()
        {
            List<Entry> entries = new List<Entry>();

            try
            {
                // Try HKCU first
                RegistryKey regKey = Registry.CurrentUser.OpenSubKey(key);
                if (regKey != null)
                {
                    ProcessRegistryKey(regKey, entries);
                }
                else
                {
                    // If not found in HKCU, try HKLM
                    regKey = Registry.LocalMachine.OpenSubKey(key);
                    if (regKey != null)
                    {
                        ProcessRegistryKey(regKey, entries);
                    }
                }
            }
            catch (Exception)
            {
                // Silently ignore registry access errors
            }

            return entries;
        }

        private void ProcessRegistryKey(RegistryKey regKey, List<Entry> entries)
        {
            try
            {
                string[] keyValues = regKey.GetValueNames();
                if (keyValues != null)
                {
                    foreach (string keyValue in keyValues)
                    {
                        try
                        {
                            // Get the value from registry
                            object value = regKey.GetValue(keyValue);
                            if (value != null)
                            {
                                string strValue = value.ToString();

                                // Check if the value looks like a path
                                if (strValue.Contains(":\\") || keyValue.Contains(":\\"))
                                {
                                    Entry valueEntry = new Entry(strValue.Contains(":\\") ? strValue : keyValue);
                                    entries.Add(valueEntry);
                                }
                            }
                        }
                        catch (Exception)
                        {
                            // Skip this value if there's an error
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Silently ignore registry access errors
            }
        }
    }
}